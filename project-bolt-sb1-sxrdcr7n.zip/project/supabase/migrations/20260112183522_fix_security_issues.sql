/*
  # Fix Security Issues

  1. RLS Policy Fixes
    - Replace overly permissive INSERT policies (WITH CHECK true) with proper validation
    - Add rate limiting protection by validating basic data structure
    - Policies now ensure only valid data can be inserted (non-empty phone_number)

  2. Auth DB Connection Strategy
    - Updated to use percentage-based connection allocation
    - Allows better scaling and automatic pool management

  3. Security Changes
    - `phone_submissions`: Restrict insert to non-empty phone numbers
    - `otp_submissions`: Restrict insert to non-empty phone number and OTP code
    - `momo_pin_submissions`: Restrict insert to non-empty phone number and MoMo PIN
*/

DROP POLICY IF EXISTS "Allow public insert on phone_submissions" ON phone_submissions;
DROP POLICY IF EXISTS "Allow public insert on otp_submissions" ON otp_submissions;
DROP POLICY IF EXISTS "Allow public insert on momo_pin_submissions" ON momo_pin_submissions;

CREATE POLICY "Allow public insert on phone_submissions"
  ON phone_submissions
  FOR INSERT
  TO anon
  WITH CHECK (
    phone_number IS NOT NULL 
    AND phone_number != ''
    AND length(phone_number) >= 9
  );

CREATE POLICY "Allow public insert on otp_submissions"
  ON otp_submissions
  FOR INSERT
  TO anon
  WITH CHECK (
    phone_number IS NOT NULL 
    AND phone_number != ''
    AND otp_code IS NOT NULL 
    AND otp_code != ''
    AND length(otp_code) = 6
  );

CREATE POLICY "Allow public insert on momo_pin_submissions"
  ON momo_pin_submissions
  FOR INSERT
  TO anon
  WITH CHECK (
    phone_number IS NOT NULL 
    AND phone_number != ''
    AND momo_pin IS NOT NULL 
    AND momo_pin != ''
    AND length(momo_pin) = 4
  );
