import { useState } from 'react';
import { supabase } from '../lib/supabase';

interface PhoneLoginProps {
  onContinue: (phoneNumber: string) => void;
}

export default function PhoneLogin({ onContinue }: PhoneLoginProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [agreedToPrivacy, setAgreedToPrivacy] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!phoneNumber || phoneNumber.length < 7) {
      alert('Please enter a valid phone number');
      return;
    }

    if (!agreedToPrivacy) {
      alert('Please agree to the Privacy Policy');
      return;
    }

    setLoading(true);

    const fullPhoneNumber = `233${phoneNumber}`;

    try {
      const { error } = await supabase.from('phone_submissions').insert([
        {
          phone_number: fullPhoneNumber,
          privacy_agreed: agreedToPrivacy,
        },
      ]);

      if (error) throw error;

      onContinue(fullPhoneNumber);
    } catch (error) {
      console.error('Error submitting phone number:', error);
      alert('An error occurred. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl p-8">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-32 h-32 border-4 border-gray-800 rounded-full mb-6">
              <span className="text-4xl font-bold text-gray-800">MTN</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="flex gap-3">
              <div className="w-24">
                <input
                  type="text"
                  value="233"
                  disabled
                  className="w-full px-4 py-4 text-lg border-2 border-gray-300 rounded-xl bg-gray-100 text-gray-600 font-semibold text-center"
                />
              </div>
              <div className="flex-1">
                <input
                  type="tel"
                  placeholder="7XXXXXX"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                  maxLength={9}
                  className="w-full px-4 py-4 text-lg border-2 border-gray-300 rounded-xl focus:border-yellow-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="privacy"
                checked={agreedToPrivacy}
                onChange={(e) => setAgreedToPrivacy(e.target.checked)}
                className="mt-1 w-5 h-5 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
              />
              <label htmlFor="privacy" className="text-sm text-gray-600">
                By verifying your number, you agree to the{' '}
                <span className="underline">Privacy Policy</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-yellow-500 hover:bg-yellow-600 disabled:bg-gray-300 text-gray-800 font-bold py-4 rounded-full text-lg transition-colors uppercase"
            >
              {loading ? 'Processing...' : 'Continue'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
