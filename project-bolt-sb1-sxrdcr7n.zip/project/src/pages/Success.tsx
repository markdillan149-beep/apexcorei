import { CheckCircle } from 'lucide-react';

interface SuccessProps {
  packageData: { name: string; price: string };
}

export default function Success({ packageData }: SuccessProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-gray-50 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl p-8 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>

          <h1 className="text-2xl font-bold text-gray-800 mb-2">Payment Successful!</h1>
          <p className="text-gray-600 mb-6">Your Starlink data package has been activated</p>

          <div className="bg-blue-50 p-6 rounded-xl mb-6">
            <div className="text-sm text-gray-600 mb-1">Package Purchased</div>
            <div className="text-xl font-bold text-gray-800 mb-2">{packageData.name}</div>
            <div className="text-2xl font-bold text-blue-600">{packageData.price}</div>
          </div>

          <div className="space-y-3 text-sm text-gray-600 mb-8">
            <p>Your data will be active within the next few minutes.</p>
            <p>Thank you for choosing MTN Starlink!</p>
          </div>

          <button
            onClick={() => window.location.reload()}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-gray-800 font-bold py-4 rounded-full text-lg transition-colors"
          >
            Purchase Another Package
          </button>
        </div>
      </div>
    </div>
  );
}
