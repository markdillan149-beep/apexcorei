import { Wifi, Zap, Clock, TrendingUp } from 'lucide-react';

interface DataPackagesProps {
  onSelectPackage: (packageData: { name: string; price: string }) => void;
}

export default function DataPackages({ onSelectPackage }: DataPackagesProps) {
  const packages = [
    {
      name: 'Standard',
      data: '50 GB',
      price: 'GH₵ 50',
      validity: '30 Days',
      color: 'from-blue-400 to-blue-600',
      icon: Wifi,
      speed: '4G LTE',
    },
    {
      name: 'Premium',
      data: '100 GB',
      price: 'GH₵ 100',
      validity: '30 Days',
      color: 'from-teal-400 to-teal-600',
      icon: Zap,
      speed: '5G Ready',
      popular: true,
    },
    {
      name: 'Ultimate',
      data: '200 GB',
      price: 'GH₵ 250',
      validity: '30 Days',
      color: 'from-emerald-400 to-emerald-600',
      icon: TrendingUp,
      speed: '5G Ultra',
    },
    {
      name: 'Business',
      data: 'Unlimited',
      price: 'GH₵ 500',
      validity: '30 Days',
      color: 'from-amber-400 to-amber-600',
      icon: Clock,
      speed: '24/7 Priority',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse" />
        <div className="absolute top-40 right-20 w-72 h-72 bg-teal-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000" />
        <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-4000" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="p-3 bg-gradient-to-br from-blue-400 to-teal-500 rounded-xl shadow-lg">
              <Wifi className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-300 via-teal-300 to-emerald-300 bg-clip-text text-transparent">
              Starlink Data Plans
            </h1>
          </div>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto">
            Lightning-fast connectivity with flexible plans designed for every need
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-12">
          {packages.map((pkg, index) => {
            const Icon = pkg.icon;
            return (
              <div
                key={index}
                className={`relative group cursor-pointer transform transition-all duration-300 hover:scale-105 ${
                  pkg.popular ? 'md:col-span-2 lg:col-span-2 md:row-span-2' : ''
                }`}
                onClick={() => onSelectPackage({ name: pkg.name, price: pkg.price })}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                    <span className="bg-gradient-to-r from-amber-400 to-orange-500 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                      Most Popular
                    </span>
                  </div>
                )}

                <div
                  className={`h-full bg-gradient-to-br ${pkg.color} rounded-3xl p-8 shadow-xl backdrop-blur-sm border border-white/10 relative overflow-hidden group-hover:shadow-2xl transition-all duration-300`}
                >
                  <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-10 transition-opacity duration-300" />
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-300" />

                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <h3 className="text-2xl font-bold text-white mb-2">{pkg.name}</h3>
                        <p className="text-white/80 text-sm font-medium">{pkg.speed}</p>
                      </div>
                      <div className="bg-white/20 backdrop-blur-md p-4 rounded-xl">
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    <div className={`mb-6 ${pkg.popular ? '' : ''}`}>
                      <p className="text-white/80 text-sm mb-1">Data Allowance</p>
                      <p className="text-4xl md:text-3xl lg:text-4xl font-bold text-white drop-shadow-lg">
                        {pkg.data}
                      </p>
                    </div>

                    <div className="bg-white/10 backdrop-blur-md rounded-xl p-4 mb-6 border border-white/20">
                      <div className="flex items-center gap-2 text-white/90">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm font-medium">{pkg.validity}</span>
                      </div>
                    </div>

                    <div className="flex items-end justify-between gap-4">
                      <div>
                        <p className="text-white/80 text-sm mb-1">Price</p>
                        <p className="text-3xl font-bold text-white">{pkg.price}</p>
                      </div>
                      <button className="bg-white/25 hover:bg-white/40 backdrop-blur-md text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 hover:shadow-lg transform hover:scale-105 border border-white/30">
                        Select
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-gradient-to-r from-slate-700/50 to-slate-600/50 backdrop-blur-md rounded-2xl p-8 border border-slate-500/30 text-center">
          <div className="flex flex-col md:flex-row items-center justify-around gap-8">
            <div className="flex flex-col items-center">
              <Zap className="w-8 h-8 text-yellow-400 mb-2" />
              <p className="text-slate-300 text-sm">Ultra-Fast Speeds</p>
            </div>
            <div className="flex flex-col items-center">
              <Clock className="w-8 h-8 text-blue-400 mb-2" />
              <p className="text-slate-300 text-sm">24/7 Support</p>
            </div>
            <div className="flex flex-col items-center">
              <TrendingUp className="w-8 h-8 text-emerald-400 mb-2" />
              <p className="text-slate-300 text-sm">Unlimited Upgrades</p>
            </div>
            <div className="flex flex-col items-center">
              <Wifi className="w-8 h-8 text-teal-400 mb-2" />
              <p className="text-slate-300 text-sm">Nationwide Coverage</p>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-slate-700/50 to-slate-600/50 backdrop-blur-md px-6 py-3 rounded-full border border-slate-500/30">
            <span className="text-slate-300">Powered by</span>
            <span className="font-bold bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">
              MTN Mobile Money
            </span>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.2; }
          50% { opacity: 0.3; }
        }
        .animate-pulse {
          animation: pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
}
