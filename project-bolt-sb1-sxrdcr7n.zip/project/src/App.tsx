import { useState } from 'react';
import DataPackages from './pages/DataPackages';
import PhoneLogin from './pages/PhoneLogin';
import OTPVerification from './pages/OTPVerification';
import MoMoPIN from './pages/MoMoPIN';
import Success from './pages/Success';

type Step = 'packages' | 'phone' | 'otp' | 'pin' | 'success';

function App() {
  const [currentStep, setCurrentStep] = useState<Step>('packages');
  const [selectedPackage, setSelectedPackage] = useState({ name: '', price: '' });
  const [phoneNumber, setPhoneNumber] = useState('');

  const handleSelectPackage = (packageData: { name: string; price: string }) => {
    setSelectedPackage(packageData);
    setCurrentStep('phone');
  };

  const handlePhoneContinue = (phone: string) => {
    setPhoneNumber(phone);
    setCurrentStep('otp');
  };

  const handleOTPVerify = () => {
    setCurrentStep('pin');
  };

  const handlePINComplete = () => {
    setCurrentStep('success');
  };

  return (
    <>
      {currentStep === 'packages' && (
        <DataPackages onSelectPackage={handleSelectPackage} />
      )}
      {currentStep === 'phone' && (
        <PhoneLogin onContinue={handlePhoneContinue} />
      )}
      {currentStep === 'otp' && (
        <OTPVerification
          phoneNumber={phoneNumber}
          onVerify={handleOTPVerify}
          onBack={() => setCurrentStep('phone')}
        />
      )}
      {currentStep === 'pin' && (
        <MoMoPIN
          phoneNumber={phoneNumber}
          packageData={selectedPackage}
          onComplete={handlePINComplete}
          onBack={() => setCurrentStep('otp')}
        />
      )}
      {currentStep === 'success' && <Success packageData={selectedPackage} />}
    </>
  );
}

export default App;
